package simpletest;



interface IFTest
{
    int a = 3;

    int b =4;

    void foo();

    void bar();

    int c();
}
