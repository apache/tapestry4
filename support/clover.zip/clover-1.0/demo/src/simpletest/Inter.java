package simpletest;

interface Inter
{
    class Inner
    {
        private String msg;

        static void s1() {
            String name = Inner.class.getName();
            for (int i = 0; i < name.length(); i++)
                if (name.charAt(i) == 'q')
                    break;
        }

        Inner(String msg)
        {
            this.msg = msg;
        }

        Inner() {
            this("empty");
        }

        boolean m1() {
            return msg != null;
        }
    }
}
