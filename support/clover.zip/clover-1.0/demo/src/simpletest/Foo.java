package simpletest;



public class Foo
{
    private boolean testing = false;
    private boolean foo = true;

    private String mMsg;

    public Foo() {

    }

    public  Foo(String aMsg)
    {
        mMsg = aMsg;
    }


    public String append(String aMsg)
    {
        mMsg = mMsg + aMsg;
        return mMsg;
    }

    public String append(int i)
    {
        mMsg = mMsg + i;
        return mMsg;
    }

    public void testThis() {
        if (testing) {
            mMsg += mMsg;
            if (foo) {
                mMsg += mMsg;
            }
        }
    }

    public void setIndex( int index )
    {
        Object        parent;
        Object    options;
        Object        item;

        parent = getClass();

        if ( parent != null )
        {
            options = ( (Object) parent ).getClass();
            if ( options.getClass() != this.getClass() )
            {
                getClass().getName();
                item = options.getClass( );
                item.getClass().getName( );
            }
        }
    }
}

// a second top level class
class Bar
{

    void whatever()
    {
        int i = 3;
        System.currentTimeMillis();
    }


}
