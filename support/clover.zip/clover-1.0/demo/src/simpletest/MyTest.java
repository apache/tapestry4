package simpletest;



public class MyTest
{

    interface MyInnerIF
    {
        public void test();
    }

    static double i;
    static
    {
        i = Math.sin(3*Math.PI);
    }

///CLOVER:OFF
    int instancevar;
    {
        instancevar = 5*(int)i;
    }
///CLOVER:ON


    private boolean testing;
    {
        testing = false;
    }



    static class Inner
    {

        private int num;
        private boolean dbg = true;

	public Inner() {};

        public Inner(int i)
        {
            this(i, true);
        }

        public Inner(int i, boolean dbg)
        {
            num = i;
            this.dbg = dbg;
        }
    }


    private String foo;
    private boolean debug = false;


    public MyTest(String blah)
    {
        this();

        if (debug)
            try {
                debug = true;
            }
            finally {
                debug = false;
            }
    }

    public MyTest(int count)
    {
        super();
    }

    public void setWhatever(MyTest.MyInnerIF aObj)
    {
        aObj.test();
    }


    public MyTest()
    {
        foo = "blah";
        Foo myFoo = new Foo(foo);

        for (int i = 0; ; i++) {
            if (i > 8) break;
        }

        int j = 0;

        for (int i = 0; i < 100; i ++) {
            if (i > 100) {
                j = i; // Should never be hit
            }
            else {
                j = -i; // should have hit count of 100
            }
        }
        j = 0;

        if (foo.length() > 3)
            j++;
        Object blah = null;
        if (foo == "blah")
            try {
                while (j++ < 60)
                    if (debug)
                        blah = new Integer(4);
                    else if (j == 30)
                        throw new Exception();
                    else if (j == 50)
                        blah = new Integer(5); // never hit
                    else
                        blah = new Integer(2);
            }
            catch (Exception e) {
                e.getMessage();
            }


        int g = 0;
        do
            g++;
        while (g < 5);

        Object next = new Object();
        Object current = new Object();

        if (current.equals(next)) {
            current = current.getClass();
        }
        //foo
        else //foo
        {
            next = null;
            current = next;
        }

        Class yikes;
        if (next != null && (yikes = getClass()) != null) {
            yikes.getName(); // use in the loop
        }

        Object ch;
        int p = 0;
        do {
            if ((ch = getClass()) != null)
                break;
            p++;
        } while (p < 10);
        ch.hashCode();


    }

    private void emptyMethodTrailingSemi() {};

    public int constantWhileCond() {

	while (true) {
		return 5;
        }
    }

    public void callMe() {
      // I don't actually do anything;
    }

    public static void main(final String [] args)
    {
        MyTest t = new MyTest();
        t.setWhatever(new MyTest.MyInnerIF() {

                public void test()
                {
                    if (args.length > 0) {
                        String arg0 = args[0];
                        if (arg0 != null) {
                            arg0.substring(0);
                        }
                    }

                }

            });

        // annonymous inner decl
        MyTest.MyInnerIF anon = new MyTest.MyInnerIF() {
                public void test()
                {
                    if (args.length > 0) {
                        String arg0 = args[0];
                        if (arg0 != null) {
                            arg0.substring(0);
                        }
                    }

                }
            };
        t.setWhatever(anon);

        Inter.Inner.s1();
        final Inter.Inner ii = new Inter.Inner();
        ii.m1();
        System.out.println("test completed");
    }
}
